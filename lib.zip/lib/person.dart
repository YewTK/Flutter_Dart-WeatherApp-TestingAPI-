import 'package:json_annotation/json_annotation.dart';
import 'package:hive/hive.dart';
part 'person.g.dart';
@HiveType(typeId: 1)
@JsonSerializable()
class Person {
  @HiveField(0)
  String name;
  @HiveField(1)
  String height;
  @HiveField(2)
  String mass;
  @HiveField(3)
  String hair_color;
  @HiveField(4)
  String skin_color;
  @HiveField(5)
  String eye_color;
  @HiveField(6)
  String birth_year;
  @HiveField(7)
  String gender;


  Person({required this.name, required this.height, required this.mass, required this.hair_color, required this.skin_color, required this.eye_color, required this.birth_year, required this.gender});
  factory Person.fromJson(Map<String, dynamic> json) => _$PersonFromJson(json);
  Map<String, dynamic> toJson() => _$PersonToJson(this);
}
