import 'dart:convert';

import 'package:hive/hive.dart';
import 'package:http/http.dart' as http;
import 'package:lab/person.dart';
import 'package:riverpod_annotation/riverpod_annotation.dart';

part 'person_notifier.g.dart';

@riverpod
class PersonNotifier extends _$PersonNotifier {
  @override
  List<Person> build() {
    final box = Hive.box<Person>('personBox');
    final persons = box.values.toList();
    if (persons.isEmpty) {
      // หากยังไม่มีข้อมูลใน Hive ให้เรียกดึงข้อมูลจาก SWAPI
      fetchAndStorePersons();
    }
    return persons;
  }

  Future<void> fetchAndStorePersons() async {
    final box = Hive.box<Person>('personBox');
    List<Person> fetched = [];
    for (int i = 1; i <= 50; i++) {
      final response =
      await http.get(Uri.parse('https://swapi.dev/api/people/$i/'));
      if (response.statusCode == 200) {
        final json = jsonDecode(response.body);
        final person = Person.fromJson(json);
        // เก็บข้อมูลลง Hive โดยใช้ key เป็น id
        await box.put(i.toString(), person);
        fetched.add(person);
      }
    }
    // อัปเดต state เมื่อดึงข้อมูลครบ
    state = fetched;
  }
}
