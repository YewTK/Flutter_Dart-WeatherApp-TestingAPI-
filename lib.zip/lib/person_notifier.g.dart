// GENERATED CODE - DO NOT MODIFY BY HAND

part of 'person_notifier.dart';

// **************************************************************************
// RiverpodGenerator
// **************************************************************************

String _$personNotifierHash() => r'335657919131d350cd66a688dba2656b39d7ce15';

/// See also [PersonNotifier].
@ProviderFor(PersonNotifier)
final personNotifierProvider =
    AutoDisposeNotifierProvider<PersonNotifier, List<Person>>.internal(
  PersonNotifier.new,
  name: r'personNotifierProvider',
  debugGetCreateSourceHash: const bool.fromEnvironment('dart.vm.product')
      ? null
      : _$personNotifierHash,
  dependencies: null,
  allTransitiveDependencies: null,
);

typedef _$PersonNotifier = AutoDisposeNotifier<List<Person>>;
// ignore_for_file: type=lint
// ignore_for_file: subtype_of_sealed_class, invalid_use_of_internal_member, invalid_use_of_visible_for_testing_member, deprecated_member_use_from_same_package
