import 'package:flutter/material.dart';
import 'package:flutter_riverpod/flutter_riverpod.dart';
import 'package:hive_flutter/hive_flutter.dart';

import 'person.dart';
import 'person_notifier.dart';

void main() async {
  WidgetsFlutterBinding.ensureInitialized();
  await Hive.initFlutter();
  Hive.registerAdapter(PersonAdapter());

  // เปิด Hive box สำหรับ Person
  await Hive.openBox<Person>('personBox');

  runApp(const ProviderScope(child: MyApp()));
}

class MyApp extends ConsumerWidget {
  const MyApp({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    return MaterialApp(
      title: 'SWAPI Characters',
      home: const PersonScreen(),
    );
  }
}

class PersonScreen extends ConsumerWidget {
  const PersonScreen({Key? key}) : super(key: key);

  @override
  Widget build(BuildContext context, WidgetRef ref) {
    // อ่านข้อมูล List<Person> จาก Riverpod
    final persons = ref.watch(personNotifierProvider);
    return Scaffold(
      appBar: AppBar(title: const Text('SWAPI Characters')),
      body: persons.isEmpty
          ? const Center(child: CircularProgressIndicator())
          : ListView.builder(
        itemCount: persons.length,
        itemBuilder: (context, index) {
          final person = persons[index];
          return ListTile(
            title: Text(person.name),
            subtitle: Text(
                'Height: ${person.height} cm, Mass: ${person.mass} kg, hair_color: ${person.hair_color} , skin_color: ${person.skin_color} , eye_color: ${person.eye_color} , birth_year: ${person.birth_year}, gender: ${person.gender}'),
          );
        },
      ),
    );
  }
}
